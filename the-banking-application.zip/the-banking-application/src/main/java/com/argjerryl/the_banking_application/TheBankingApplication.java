package com.argjerryl.the_banking_application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheBankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheBankingApplication.class, args);
	}

}
