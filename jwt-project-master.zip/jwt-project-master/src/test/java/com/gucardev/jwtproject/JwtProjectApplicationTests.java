package com.gucardev.jwtproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
