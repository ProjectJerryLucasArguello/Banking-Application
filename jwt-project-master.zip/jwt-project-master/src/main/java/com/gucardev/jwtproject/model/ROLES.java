package com.gucardev.jwtproject.model;

public enum ROLES {
    SUPERADMIN, ADMIN, USER

}
