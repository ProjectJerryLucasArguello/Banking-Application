package com.gucardev.jwtproject.model.qrLogin;

public enum LoginQRCodeType {
    SERVER, CLIENT, MOBILE, ERROR
}
