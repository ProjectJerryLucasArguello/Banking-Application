package dev.argjerryl.Exchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
